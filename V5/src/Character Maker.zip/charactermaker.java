public interface charactermaker {
	public void openingDialog();
	public void factionpick();
	public void attributePicker();
	public void skillPicker();
	public void backgrounds();
	public void powerpick();
	public void characterdetails();
	public void flawsandmerits();
	public void statcrunch();
	public void charreview();
	public void export();
	public void naturedemeanor();
	public void freebiepoints();
}
