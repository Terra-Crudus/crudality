import java.util.Random;
import java.util.Scanner;
public class C20Char implements charactermaker
{
	static Scanner input = new Scanner(System.in);
	static Random randGen = new Random();

	
	public void openingDialog() 
	{
		
	}
	
	public void attributePicker() 
	{
		// TODO Auto-generated method stub
	}

	public void skillPicker() 
	{
		// TODO Auto-generated method stub
	}
	
	public void factionpick() 
	{
		//kith
		//court
		//legacy
		//seeming
		//house
		//domain
		//dutchy
		//realm
		
	}
	
	public void backgrounds() 
	{
		
	}
	
	public void powerpick() 
	{
		//arts
		/*Autumn 197
		Chicanery 200
		Chronos 201
		Contract 203
		Dragon�s Ire 205
		Legerdemain 207
		Metamorphosis 209
		Naming 211
		Oneiromancy 213
		Primal 215
		Pyretics 217
		Skycraft 219
		Soothsay 221
		Sovereign 223
		Spring 225
		Summer 227
		Wayfare 228
		Winter
		*/
	}
	
	public void characterdetails() 
	{
		
	}
	
	public void flawsandmerits() 
	{
		
	}
	
	public void charreview() 
	{
		
	}
	
	public void naturedemeanor() 
	{
		
	}
	
	public void export() 
	{
		
	}
	
	public void freebiepoints() 
	{
		
	}
	
	public void statcrunch() 
	{
		//willpower, glamour, banality
	}


		//House Aesin, Ailil, Balor, Beaumayn, Danaan, Daireann, Dougal, Eiluned, 
		//Fiona, Gwydion, Leanhaun, Liam, Scathach, Varich	


}
