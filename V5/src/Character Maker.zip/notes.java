
public class notes {
	/* while (Condition) float nextLine to get the entire line entered as the input taken variable ++ means take the
	 * variable and increment it by 1. variable -- means take the variable and increment it 
	 * by -1 either of the
	 * incrementers can be on either side of the variable Space is not required but is allowed 
	 * \n means give a new line,put it within quotes to achieve this. Combo with print ln to create spacing 
	 * make sure to put an accumulator within a while loop 
	 * answer = line.toLowerCase(); will convert the string to entirely lower case, only works for a string,
	 * not a character you can also use uppercase, and this can be used to check yes no easily answer = line.charAt(0);
	 * so it will be converted to one character if a scanner is inside main, it needs static, if its outside main,
	 * input.close(); will close the input alphabetic at 1, prints A Alphabetic at 4, 4 spaces is a tab Char if
	 * (variable.equals("Brujah") to check a string. comparing with varible1.compareTo(variable2) < 0 (only for ints?)
	 * compare to returns a negative if the second variable is less than the first, 0 if equal, 1 if higher also
	 * varible1.equalsIgnoreCase to avoid converting the string also varible1.compareToIgnoreCase block is a list of
	 * statements surrounded by braces MAIN (defined at the beginning) is in itself a method, that is called to run first
	 * int[] numArray; 
	 * numArray = new int[50] 
	 * int[] numArray = {1,2,3} will put 1,2,3, directly as values into the array (not often needed) 
	 * size of the array will be the last variable given to go into the array
	 * myArray [0] = 5.6, myArray [1] = 3.4, etc
	 * constants go before main
	 * when an array is created, strings are null, boolean is false, and ints or floats are 0
	 * for is a counted loop 
	 * for (initialization; condition; changer)
	 * for (lcv=0; lcv<MAX; lcv++)
	 * {
	 * 	Do something like myArray [ cell# or index ] = whatever;
	 * }
	 * The Gang of Four (c++?)
	 * dispatcher method (calls a ton of other methods)
	 * How to write unmaintainable code
	 * creating a class will allow people to then create objects with that class as a template
	 * instantiate: creates a new instance of, or makes a new object
	 * public Character(String bookName)
	 * {
	 * name = characterName
	 * date = "none"
	 * author = "none"
	 * numOfWords = 0;
	 * publisher = "";
	 * }
	 * All of the following can be done in a method that the class calls 
	 * Character myCharacter = new Character ();
	 * String characterName;
	 * characterName = input.nextLn();
	 * (prompt the user to then input what they want to name it)
	 * myCharacter1.setName = ("Jerk");
	 * 
	 * a method that allows people to set the value in a class, its called a setter
	 * accessers: 
	 * getters:
	 * constructors are called when an object in instansiated
	 * default constructor sets all the values to a preset. You can then allow them in a method to change all the values
	 * name = "None"
	 * year = "0000"
	 * author = "You"
	 * a class calls methods to allow the user to define the object
	 * constructors have no return type because it is obvious
	 * a constructor, the name of the method is always the name of the class
	 * default constructor has no paramater types or arguments
	 * public Book ()
	 * class definition declares value fields
	 * constructor intializes values fields 
	 * this? what is that object or defiition
	 * substring?
	 * .toString method will print out your object in a certain way
	 * int [] [] myArray = new int [5][4] to make tables of arrays
	 * every dimension you add another square or set of brackets
	 * 
	 *\" will allow you to put quotes in strings \"hello world\"
	 *an integer is 2 bytes or 32 bits wide, biggest can be -2(to 31) - 1, 2(to 31) - 1  
	 *long, a 64 bit number or 8 bytes
	 *char 16 bits (2 bytes)
	 *double (64 bits)
	 *primitive types of variables have no class to contain them, just bits
	 *Integer is its own class 
	 *thinkjava.org/keywords for words you cant use for variables
	 *answer = (double)num1 / num2 this is typecasting so it will change the type of the output
	 *
	 *Compile Time Errors: Syntax, violate the rules of the java language
	 *Runtime Errors: Divide by 0, something unexpected has happened that breaks the program
	 *Logic Errors: Program does not produce the desired outcome. Computer is unsure what the failed logic is
	 *
	 *typecast example:
	 *int otherTemp = 0;
	 *otherTemp = (int) (celsius + fahrenheit);
	 *
	 *i +=2; // this will add 2 to the value of i. 
	 */
}
