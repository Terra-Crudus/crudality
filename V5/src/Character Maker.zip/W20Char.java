import java.util.Random;
import java.util.Scanner;

public class W20Char implements charactermaker
{
	static Scanner input = new Scanner(System.in);
	static Random randGen = new Random();
	
	public void openingDialog() 
	{

	}
	
	public void attributePicker() 
	{
		// TODO Auto-generated method stub
	}

	public void skillPicker() 
	{
		// TODO Auto-generated method stub
	}
	
	public void factionpick() 
	{
		
	}
	
	public void backgrounds() 
	{
		
	}
	
	public void powerpick() 
	{
	
	}
	
	public void characterdetails() 
	{
		
	}
	
	public void flawsandmerits() 
	{
		
	}
	
	public void charreview() 
	{
		
	}
	
	public void naturedemeanor() 
	{
		
	}
	
	public void export() 
	{
		
	}
	
	public void freebiepoints() 
	{
		
	}
	
	public void statcrunch() 
	{
		
	}
	

}
